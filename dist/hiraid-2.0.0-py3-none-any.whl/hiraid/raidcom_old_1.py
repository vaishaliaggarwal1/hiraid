from hiraid.raidcom import Raidcom
