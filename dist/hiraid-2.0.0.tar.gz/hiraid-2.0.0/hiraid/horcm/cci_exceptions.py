

class EX_ATTHOR(Exception):
    def __init__(self, message):
        super(EX_ATTHOR, self).__init__(message)
    pass

class HORCM_START(Exception):
    pass

